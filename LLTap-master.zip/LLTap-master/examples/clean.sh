#!/bin/sh
rm *.ll
rm *.bc
rm *.o
rm *.s
rm *.bin
rm core.*
